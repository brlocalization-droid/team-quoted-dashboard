import { useState, useMemo } from "react";

const TODAY = new Date("2026-03-04");

const PROJECTS = [
  { id:"P-QTD12289", pm:"Mateus Andrade", client:"Native Prime SAS", game:"Test", category:"Video Games", status:"LOADED", progress:0, clientDeadline:"2026-03-09", providers:[], wordcount:"549w" },
  { id:"P-QTD12288", pm:"Gustavo Teixeira", client:"Altagram GmbH", game:"Diablo Immortal", category:"Video Games", status:"IN_MANAGEMENT", progress:51.93, clientDeadline:"2026-03-06", providerDeadline:"2026-03-05", providers:["Júlia Spanopoulos"], wordcount:"1317w" },
  { id:"P-QTD12287", pm:"Gustavo Teixeira", client:"Thermo Fisher Scientific", game:"Traduções CAD", category:"Health care", status:"LOADED", progress:0, clientDeadline:"2026-03-09", providers:[], wordcount:"—" },
  { id:"P-QTD12286", pm:"Gustavo Teixeira", client:"Ubisoft", game:"For Honor", category:"Video Games", status:"IN_MANAGEMENT", progress:54.61, clientDeadline:"2026-03-05", providerDeadline:"2026-03-05", providers:["Wallacy Silva"], wordcount:"257w" },
  { id:"P-QTD12285", pm:"Gustavo Teixeira", client:"Altagram GmbH", game:"Diablo Immortal", category:"Video Games", status:"IN_MANAGEMENT", progress:51.67, clientDeadline:"2026-03-11", providerDeadline:"2026-03-09", providers:["Frank Holbach Duarte"], wordcount:"2107w" },
  { id:"P-QTD12284", pm:"Gustavo Teixeira", client:"Altagram GmbH", game:"Diablo Immortal", category:"Video Games", status:"IN_MANAGEMENT", progress:51.44, clientDeadline:"2026-03-06", providerDeadline:"2026-03-05", providers:["Frank Holbach Duarte"], wordcount:"747w" },
  { id:"P-QTD12283", pm:"Gustavo Teixeira", client:"Altagram GmbH", game:"Diablo Immortal", category:"Video Games", status:"IN_MANAGEMENT", progress:51.76, clientDeadline:"2026-03-04", providerDeadline:"2026-03-04", providers:["Frank Holbach Duarte"], wordcount:"230w" },
  { id:"P-QTD12281", pm:"Estéfano Vitagliano", client:"QLOC S.A.", game:"Enshrouded", category:"Video Games", status:"IN_MANAGEMENT", progress:49.96, clientDeadline:"2026-03-20", providerDeadline:"2026-03-16", providers:["Lennar Smânio Campos"], wordcount:"19014w" },
  { id:"P-QTD12280", pm:"Gustavo Teixeira", client:"Ubisoft", game:"ICEMAN", category:"Video Games", status:"IN_MANAGEMENT", progress:54.67, clientDeadline:"2026-03-05", providerDeadline:"2026-03-05", providers:["Wallacy Silva"], wordcount:"14w" },
  { id:"P-QTD12279", pm:"Gustavo Teixeira", client:"Ubisoft", game:"ICEMAN", category:"Video Games", status:"IN_MANAGEMENT", progress:54.67, clientDeadline:"2026-03-05", providerDeadline:"2026-03-05", providers:["Wallacy Silva"], wordcount:"14w" },
  { id:"P-QTD12278", pm:"Mateus Andrade", client:"Native Prime SAS", game:"Hearts of Iron 4", category:"Video Games", status:"IN_MANAGEMENT", progress:48.41, clientDeadline:"2026-03-12", providerDeadline:"2026-03-10", providers:["Vinicius T. B. Fugita"], wordcount:"10934w" },
  { id:"P-QTD12277", pm:"Mateus Andrade", client:"Altagram GmbH", game:"Sonic Rumble", category:"Video Games", status:"IN_MANAGEMENT", progress:56.54, clientDeadline:"2026-03-05", providerDeadline:"2026-03-04", providers:["Vinicius T. B. Fugita"], wordcount:"623w" },
  { id:"P-QTD12276", pm:"Gustavo Teixeira", client:"Ubisoft", game:"The Crew Motorfest", category:"Video Games", status:"IN_MANAGEMENT", progress:54.62, clientDeadline:"2026-03-05", providerDeadline:"2026-03-05", providers:["Wallacy Silva"], wordcount:"267w" },
  { id:"P-QTD12275", pm:"Dieggo Lessa Arnoldo", client:"Native Prime SAS", game:"Talos Reawakened", category:"Video Games", status:"IN_MANAGEMENT", progress:49.52, clientDeadline:"2026-03-06", providerDeadline:"2026-03-04", providers:["Lia Bittencourt","Dennys G. F. Spera"], wordcount:"223w" },
  { id:"P-QTD12274", pm:"Estéfano Vitagliano", client:"THQ Nordic GmbH", game:"Tides of Tomorrow", category:"Video Games", status:"IN_MANAGEMENT", progress:41.7, clientDeadline:"2026-03-04", providerDeadline:"2026-03-03", providers:["Beatriz P. M. Oliveira","Sandra Lia"], wordcount:"686w" },
  { id:"P-QTD12273", pm:"Estéfano Vitagliano", client:"QLOC S.A.", game:"Sengoku Dynasty", category:"Video Games", status:"IN_MANAGEMENT", progress:30.37, clientDeadline:"2026-03-04", providerDeadline:"2026-03-04", providers:["Sandra Lia de Godoy"], wordcount:"66w" },
  { id:"P-QTD12271", pm:"Dieggo Lessa Arnoldo", client:"Native Prime SAS", game:"Hawaii West (Kiln)", category:"Video Games", status:"IN_MANAGEMENT", progress:46.91, clientDeadline:"2026-03-05", providerDeadline:"2026-03-04", providers:["Lennar Smânio","Lia Bittencourt"], wordcount:"2697w" },
  { id:"P-QTD12270", pm:"Mateus Andrade", client:"Native Prime SAS", game:"Stellaris", category:"Video Games", status:"IN_MANAGEMENT", progress:47.16, clientDeadline:"2026-03-06", providerDeadline:"2026-03-04", providers:["Ramon Ferreira"], wordcount:"1972w" },
  { id:"P-QTD12266", pm:"Gustavo Teixeira", client:"Thermo Fisher Scientific", game:"Vanquish Flex UHPLC", category:"Health care", status:"LOADED", progress:0, clientDeadline:"2026-03-05", providerDeadline:"2026-03-04", providers:["Wallacy Silva"], wordcount:"3040w" },
  { id:"P-QTD12265", pm:"Mateus Andrade", client:"Native Prime SAS", game:"Caligula", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-06", providerDeadline:"2026-03-03", providers:["Júlia Spanopoulos","Beatriz D'Angelo"], wordcount:"91w" },
  { id:"P-QTD12263", pm:"Gustavo Teixeira", client:"Ubisoft", game:"For Honor", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-05", providerDeadline:"2026-03-04", providers:["Wallacy Silva"], wordcount:"440w" },
  { id:"P-QTD12260", pm:"Estéfano Vitagliano", client:"QLOC S.A.", game:"Sengoku Dynasty", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-04", providerDeadline:"2026-03-03", providers:["Beatriz P. M. Oliveira","Sandra Lia"], wordcount:"1150w" },
  { id:"P-QTD12257", pm:"Dieggo Lessa Arnoldo", client:"Native Prime SAS", game:"Caesar (EU V)", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-16", providerDeadline:"2026-03-04", providers:["Osman Alves","Ramon Lourenço"], wordcount:"28122w" },
  { id:"P-QTD12256", pm:"Estéfano Vitagliano", client:"Native Prime SAS", game:"Dominion / Runescape", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-05", providerDeadline:"2026-03-03", providers:["Lennar Smânio","Ricardo Douglas","Beatriz D'Angelo"], wordcount:"3586w" },
  { id:"P-QTD12254", pm:"Gustavo Teixeira", client:"Ubisoft", game:"For Honor", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-05", providerDeadline:"2026-03-03", providers:["Wallacy Silva","Diva Nogueira"], wordcount:"719w" },
  { id:"P-QTD12252", pm:"Mateus Andrade", client:"Native Prime SAS", game:"Caligula", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-05", providerDeadline:"2026-03-03", providers:["Júlia Spanopoulos","Beatriz D'Angelo"], wordcount:"860w" },
  { id:"P-QTD12248", pm:"Gustavo Teixeira", client:"Altagram GmbH", game:"Diablo Immortal", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-05", providerDeadline:"2026-03-03", providers:["Júlia Spanopoulos","Frank Holbach Duarte"], wordcount:"8073w" },
  { id:"P-QTD12241", pm:"Gustavo Teixeira", client:"Accor Brasil", game:"Employee Dashboard", category:"Travel & Tourism", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-06", providerDeadline:"2026-03-05", providers:["Cyro Leão"], wordcount:"11102w" },
  { id:"P-QTD12239", pm:"Mateus Andrade", client:"Native Prime SAS", game:"Thallium (EL2)", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2026-03-05", providerDeadline:"2026-03-02", providers:["Ricardo Douglas","Dennys G. F. Spera","Lia Bittencourt"], wordcount:"966w" },
  { id:"P-QTD12220", pm:"Samuel Coelho", client:"Sony Interactive", game:"Edamame", category:"Video Games", status:"IN_MANAGEMENT", progress:null, clientDeadline:"2027-02-16", providerDeadline:"2026-03-06", providers:["Rodrigo Segatti","Dennys G. F. Spera","Maria Paula C. Bueno"], wordcount:"5918w" },
  { id:"P-QTD12217", pm:"Gustavo Teixeira", client:"GameHouse Europe", game:"Matchventures-4", category:"Video Games", status:"IN_MANAGEMENT", progress:46.49, clientDeadline:"2026-03-09", providerDeadline:"2026-03-05", providers:["Rodrigo Segatti","Diva Nogueira"], wordcount:"18521w" },
  { id:"P-QTD12208", pm:"Samuel Coelho", client:"Locpick", game:"Fortnite", category:"Video Games", status:"LOADED", progress:0, clientDeadline:"2026-03-03", providers:[], wordcount:"—" },
  { id:"P-QTD12207", pm:"Gustavo Teixeira", client:"Aplus Translations", game:"Serif Marketing", category:"IT & Software", status:"IN_MANAGEMENT", progress:42.32, clientDeadline:"2026-02-28", providerDeadline:"2026-02-28", providers:["Cyro Leão"], wordcount:"10h" },
  { id:"P-QTD12180", pm:"Dieggo Lessa Arnoldo", client:"Native Prime SAS", game:"Descent", category:"Video Games", status:"IN_MANAGEMENT", progress:60.6, clientDeadline:"2026-03-10", providerDeadline:"2026-02-26", providers:["Beatriz P. M. Oliveira","Sandra Lia"], wordcount:"23752w" },
  { id:"P-QTD12126", pm:"Mateus Andrade", client:"QLOC S.A.", game:"General", category:"Video Games", status:"LOADED", progress:0, clientDeadline:"2026-02-23", providers:[], wordcount:"—" },
  { id:"P-QTD12114", pm:"Samuel Coelho", client:"Sony Interactive", game:"Edamame Drop22", category:"Video Games", status:"IN_MANAGEMENT", progress:86.74, clientDeadline:"2026-03-06", providerDeadline:"2026-02-24", providers:["Maria Paula C. Bueno","Nick Casabona"], wordcount:"5575w + 85h" },
  { id:"P-QTD12113", pm:"Thiago Kunis", client:"Sony Interactive", game:"i38 Batch 2", category:"Video Games", status:"IN_MANAGEMENT", progress:79.12, clientDeadline:"2026-03-20", providerDeadline:"2026-02-20", providers:["Wallacy Silva","Ramon Lourenço","Beatriz P. M. Oliveira"], wordcount:"37283w + 164h" },
  { id:"P-QTD12102", pm:"Estéfano Vitagliano", client:"QLOC S.A.", game:"Sparta (Mortal Shell)", category:"Video Games", status:"IN_MANAGEMENT", progress:68.16, clientDeadline:"2026-03-24", providerDeadline:"2026-02-19", providers:["Michel Dornes","Vinicius T. B. Fugita","Marianna Oliveira"], wordcount:"27337w" },
  { id:"P-QTD11959", pm:"Mateus Andrade", client:"Altagram GmbH", game:"Industria 2", category:"Video Games", status:"IN_MANAGEMENT", progress:75.55, clientDeadline:"2026-03-06", providerDeadline:"2026-02-09", providers:["Vinicius T. B. Fugita","Beatriz P. M. Oliveira"], wordcount:"9135w" },
  { id:"P-QTD11738", pm:"Thiago Kunis", client:"Sony Interactive", game:"Edamame Drop21", category:"Video Games", status:"IN_MANAGEMENT", progress:75.47, clientDeadline:"2026-03-04", providerDeadline:"2026-01-22", providers:["Maria Paula C. Bueno","Nick Casabona"], wordcount:"1445w + 30h" },
  { id:"P-QTD11737", pm:"Thiago Kunis", client:"Sony Interactive", game:"Edamame Drop20", category:"Video Games", status:"IN_MANAGEMENT", progress:79.43, clientDeadline:"2026-03-04", providerDeadline:"2026-01-22", providers:["Maria Paula C. Bueno","Dennys G. F. Spera"], wordcount:"4097w + 57h" },
  { id:"P-QTD11675", pm:"Samuel Coelho", client:"Sony Interactive", game:"Edamame Drop19", category:"Video Games", status:"IN_MANAGEMENT", progress:79.93, clientDeadline:"2026-03-04", providerDeadline:"2026-01-16", providers:["Maria Paula C. Bueno","Nick Casabona"], wordcount:"1933w + 41h" },
  { id:"Q-QTD11527", pm:"Thiago Kunis", client:"Warner Bros South", game:"General", category:"Media & Marketing", status:"PENDING", progress:0, clientDeadline:"2025-12-19", providers:[], wordcount:"—" },
  { id:"P-QTD11483", pm:"Thiago Kunis", client:"Native Prime SAS", game:"Titanic VR Experience", category:"Video Games", status:"LOADED", progress:0, clientDeadline:"2025-12-12", providers:[], wordcount:"—" },
  { id:"P-QTD11436", pm:"Samuel Coelho", client:"Sony Interactive", game:"Edamame", category:"Video Games", status:"LOADED", progress:0, clientDeadline:"2025-12-19", providers:[], wordcount:"—" },
  { id:"Q-QTD11418", pm:"Thiago Kunis", client:"Native Prime SAS", game:"Titanic VR Experience", category:"Video Games", status:"PENDING", progress:0, clientDeadline:"2026-01-09", providers:[], wordcount:"—" },
];

const PM_COLORS = {
  "Gustavo Teixeira":    "#60A5FA",
  "Mateus Andrade":      "#34D399",
  "Estéfano Vitagliano": "#F59E0B",
  "Dieggo Lessa Arnoldo":"#A78BFA",
  "Samuel Coelho":       "#F472B6",
  "Thiago Kunis":        "#FB923C",
};

function daysUntil(dateStr) {
  const d = new Date(dateStr) - TODAY;
  return Math.ceil(d / 86400000);
}

function getUrgency(p) {
  if (p.status === "PENDING") return "pending";
  const days = daysUntil(p.clientDeadline);
  if (days < 0) return "overdue";
  if (days === 0) return "today";
  if (days <= 2) return "soon";
  return "ok";
}

const URGENCY = {
  overdue: { label: "Atrasado",    color: "#EF4444", bg: "rgba(239,68,68,0.12)" },
  today:   { label: "Hoje",        color: "#F97316", bg: "rgba(249,115,22,0.12)" },
  soon:    { label: "Em breve",    color: "#EAB308", bg: "rgba(234,179,8,0.12)" },
  ok:      { label: "No prazo",    color: "#22C55E", bg: "rgba(34,197,94,0.12)" },
  pending: { label: "Pendente",    color: "#6B7280", bg: "rgba(107,114,128,0.1)" },
};

const STATUS_LABEL = { IN_MANAGEMENT: "Em gestão", LOADED: "Carregado", PENDING: "Pendente" };

function Badge({ urgency }) {
  const u = URGENCY[urgency];
  return <span style={{ fontSize:10, fontWeight:700, letterSpacing:"0.06em", textTransform:"uppercase",
    padding:"2px 8px", borderRadius:20, background:u.bg, color:u.color, whiteSpace:"nowrap" }}>{u.label}</span>;
}

function PmDot({ pm }) {
  return <span style={{ display:"inline-flex", alignItems:"center", gap:5 }}>
    <span style={{ width:7, height:7, borderRadius:"50%", background:PM_COLORS[pm]||"#888", display:"inline-block", flexShrink:0 }} />
    <span style={{ fontSize:12, color: PM_COLORS[pm]||"#aaa", fontWeight:500 }}>{pm.split(" ")[0]}</span>
  </span>;
}

function ProgressPill({ val }) {
  if (val === null || val === undefined) return <span style={{ color:"#333", fontSize:11 }}>—</span>;
  const color = val >= 75 ? "#22C55E" : val >= 40 ? "#EAB308" : "#EF4444";
  return <div style={{ display:"flex", alignItems:"center", gap:6 }}>
    <div style={{ width:52, height:4, background:"#1E1E3A", borderRadius:2, overflow:"hidden" }}>
      <div style={{ height:"100%", width:`${val}%`, background:color, borderRadius:2 }} />
    </div>
    <span style={{ fontSize:11, color, fontFamily:"'DM Mono',monospace", fontWeight:600 }}>{val.toFixed(0)}%</span>
  </div>;
}

export default function App() {
  const [pmFilter, setPmFilter] = useState("todos");
  const [urgFilter, setUrgFilter] = useState("todos");
  const [clientFilter, setClientFilter] = useState("todos");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("deadline");
  const [view, setView] = useState("table");

  const pms = [...new Set(PROJECTS.map(p => p.pm))];
  const clients = [...new Set(PROJECTS.map(p => p.client))].sort();

  const enriched = useMemo(() => PROJECTS.map(p => ({ ...p, urgency: getUrgency(p), days: daysUntil(p.clientDeadline) })), []);

  const filtered = useMemo(() => enriched
    .filter(p => pmFilter === "todos" || p.pm === pmFilter)
    .filter(p => urgFilter === "todos" || p.urgency === urgFilter)
    .filter(p => clientFilter === "todos" || p.client === clientFilter)
    .filter(p => !search || p.id.toLowerCase().includes(search.toLowerCase()) ||
      p.game.toLowerCase().includes(search.toLowerCase()) ||
      p.client.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sort === "deadline") return new Date(a.clientDeadline) - new Date(b.clientDeadline);
      if (sort === "progress") return (b.progress||0) - (a.progress||0);
      if (sort === "pm") return a.pm.localeCompare(b.pm);
      return 0;
    }), [enriched, pmFilter, urgFilter, clientFilter, search, sort]);

  const stats = useMemo(() => ({
    total: enriched.length,
    inMgmt: enriched.filter(p=>p.status==="IN_MANAGEMENT").length,
    overdue: enriched.filter(p=>p.urgency==="overdue").length,
    today: enriched.filter(p=>p.urgency==="today").length,
    soon: enriched.filter(p=>p.urgency==="soon").length,
  }), [enriched]);

  const pmStats = useMemo(() => pms.map(pm => {
    const mine = enriched.filter(p => p.pm === pm);
    return { pm, total: mine.length, overdue: mine.filter(p=>p.urgency==="overdue").length,
      today: mine.filter(p=>p.urgency==="today").length, soon: mine.filter(p=>p.urgency==="soon").length };
  }).sort((a,b) => b.total - a.total), [enriched, pms]);

  const clientStats = useMemo(() => {
    const map = {};
    enriched.forEach(p => { if (!map[p.client]) map[p.client] = 0; map[p.client]++; });
    return Object.entries(map).sort((a,b)=>b[1]-a[1]).slice(0,8);
  }, [enriched]);

  return (
    <div style={{ background:"#080812", minHeight:"100vh", color:"#C8C8E0",
      fontFamily:"'Sora',sans-serif", padding:"20px 24px", fontSize:13 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        .card{background:#0F0F22;border:1px solid #1A1A30;border-radius:12px;}
        .mono{font-family:'DM Mono',monospace;}
        ::-webkit-scrollbar{height:4px;width:4px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:#2A2A40;border-radius:4px;}
        tr:hover td{background:#13132A;}
        .chip{border:1px solid #1A1A30;background:transparent;border-radius:20px;padding:4px 11px;
          font-size:11px;font-family:'Sora',sans-serif;cursor:pointer;color:#555;transition:all 0.15s;}
        .chip.active{border-color:currentColor;}
        input{background:#0F0F22;border:1px solid #1A1A30;color:#C8C8E0;border-radius:8px;
          padding:6px 12px;font-family:'Sora',sans-serif;font-size:12px;outline:none;width:200px;}
        input::placeholder{color:#333;}
        .tab{background:transparent;border:none;cursor:pointer;padding:7px 14px;border-radius:8px;
          font-family:'Sora',sans-serif;font-size:12px;font-weight:500;color:#444;transition:all 0.15s;}
        .tab.active{background:#1A1A30;color:#fff;}
        select{background:#0F0F22;border:1px solid #1A1A30;color:#888;border-radius:8px;
          padding:5px 10px;font-family:'Sora',sans-serif;font-size:11px;outline:none;cursor:pointer;}
      `}</style>

      {/* HEADER */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
        <div>
          <p style={{ fontSize:10, color:"#333", letterSpacing:"0.1em", textTransform:"uppercase", fontFamily:"'DM Mono',monospace", marginBottom:5 }}>
            Terrasoft · Team Quoted
          </p>
          <h1 style={{ fontSize:21, fontWeight:700, color:"#fff", letterSpacing:"-0.03em" }}>
            Project Status Board
          </h1>
          <p style={{ fontSize:11, color:"#444", marginTop:3 }}>
            04 Mar 2026 · {stats.total} projetos ·{" "}
            {stats.overdue > 0 && <span style={{ color:"#EF4444" }}>{stats.overdue} atrasado{stats.overdue>1?"s":""} ⚠ · </span>}
            {stats.today > 0 && <span style={{ color:"#F97316" }}>{stats.today} vencem hoje · </span>}
            <span style={{ color:"#EAB308" }}>{stats.soon} vencem em breve</span>
          </p>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          {["table","pms","clients"].map(v=>(
            <button key={v} className={`tab ${view===v?"active":""}`} onClick={()=>setView(v)}>
              {v==="table"?"📋 Projetos":v==="pms"?"👤 PMs":"🏢 Clientes"}
            </button>
          ))}
        </div>
      </div>

      {/* KPI STRIP */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:10, marginBottom:16 }}>
        {[
          { label:"Total",        val:stats.total,          color:"#60A5FA", sub:"projetos ativos" },
          { label:"Em Gestão",    val:stats.inMgmt,         color:"#34D399", sub:"in management" },
          { label:"Atrasados",    val:stats.overdue,        color:"#EF4444", sub:"passaram do prazo" },
          { label:"Vencem Hoje",  val:stats.today,          color:"#F97316", sub:"deadline 04/03" },
          { label:"Em breve",     val:stats.soon,           color:"#EAB308", sub:"próximos 2 dias" },
        ].map(k=>(
          <div key={k.label} className="card" style={{ padding:"14px 16px", borderTop:`2px solid ${k.color}`, cursor:"pointer" }}
            onClick={()=>{ if(k.label==="Atrasados") setUrgFilter(urgFilter==="overdue"?"todos":"overdue");
              else if(k.label==="Vencem Hoje") setUrgFilter(urgFilter==="today"?"todos":"today");
              else if(k.label==="Em breve") setUrgFilter(urgFilter==="soon"?"todos":"soon"); }}>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:6 }}>{k.label}</div>
            <div className="mono" style={{ fontSize:32, fontWeight:500, color:"#fff", lineHeight:1 }}>{k.val}</div>
            <div style={{ fontSize:10, color:k.color, marginTop:5 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      {/* ── VIEW: TABLE ── */}
      {view === "table" && (<>
        {/* FILTERS */}
        <div style={{ display:"flex", gap:8, marginBottom:12, flexWrap:"wrap", alignItems:"center" }}>
          <input placeholder="🔍  Buscar ID, jogo, cliente..." value={search} onChange={e=>setSearch(e.target.value)} />

          <div style={{ display:"flex", gap:6, alignItems:"center" }}>
            <span style={{ fontSize:10, color:"#444" }}>Urgência:</span>
            {["todos","overdue","today","soon","ok"].map(u=>(
              <button key={u} className={`chip ${urgFilter===u?"active":""}`}
                style={{ color: urgFilter===u ? (URGENCY[u]?.color||"#60A5FA") : "#555" }}
                onClick={()=>setUrgFilter(u)}>
                {u==="todos"?"Todos":URGENCY[u]?.label}
              </button>
            ))}
          </div>

          <div style={{ display:"flex", gap:6, alignItems:"center", marginLeft:"auto" }}>
            <span style={{ fontSize:10, color:"#444" }}>PM:</span>
            <select value={pmFilter} onChange={e=>setPmFilter(e.target.value)}>
              <option value="todos">Todos</option>
              {pms.map(p=><option key={p} value={p}>{p.split(" ")[0]}</option>)}
            </select>
            <span style={{ fontSize:10, color:"#444" }}>Cliente:</span>
            <select value={clientFilter} onChange={e=>setClientFilter(e.target.value)}>
              <option value="todos">Todos</option>
              {clients.map(c=><option key={c} value={c}>{c}</option>)}
            </select>
            <span style={{ fontSize:10, color:"#444" }}>Ordenar:</span>
            <select value={sort} onChange={e=>setSort(e.target.value)}>
              <option value="deadline">Prazo</option>
              <option value="progress">Progresso</option>
              <option value="pm">PM</option>
            </select>
          </div>
        </div>

        {/* TABLE */}
        <div className="card" style={{ overflow:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", minWidth:900 }}>
            <thead>
              <tr style={{ borderBottom:"1px solid #1A1A30" }}>
                {["ID","Jogo / Projeto","Cliente","PM","Prazo cliente","Progresso","Prestadores","Status"].map(h=>(
                  <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:9, color:"#444",
                    fontWeight:700, letterSpacing:"0.08em", textTransform:"uppercase", whiteSpace:"nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => {
                const urg = URGENCY[p.urgency];
                return (
                  <tr key={p.id} style={{ borderBottom:"1px solid #12122A",
                    background: p.urgency==="overdue" ? "rgba(239,68,68,0.03)" : p.urgency==="today" ? "rgba(249,115,22,0.03)" : "transparent" }}>
                    <td style={{ padding:"10px 14px" }}>
                      <span className="mono" style={{ fontSize:10, color:"#555" }}>{p.id}</span>
                    </td>
                    <td style={{ padding:"10px 14px", maxWidth:200 }}>
                      <div style={{ fontWeight:600, color:"#fff", fontSize:12 }}>{p.game}</div>
                      <div style={{ fontSize:10, color:"#444", marginTop:2 }}>{p.wordcount}</div>
                    </td>
                    <td style={{ padding:"10px 14px" }}>
                      <span style={{ fontSize:11, color:"#888" }}>{p.client}</span>
                    </td>
                    <td style={{ padding:"10px 14px" }}>
                      <PmDot pm={p.pm} />
                    </td>
                    <td style={{ padding:"10px 14px", whiteSpace:"nowrap" }}>
                      <div style={{ fontSize:12, color: urg.color, fontWeight:600 }}>
                        {p.days < 0 ? `${Math.abs(p.days)}d atraso` : p.days === 0 ? "Hoje" : `+${p.days}d`}
                      </div>
                      <div style={{ fontSize:10, color:"#333", marginTop:2 }}>
                        {p.clientDeadline.split("-").reverse().join("/")}
                      </div>
                    </td>
                    <td style={{ padding:"10px 14px" }}>
                      <ProgressPill val={p.progress} />
                    </td>
                    <td style={{ padding:"10px 14px", maxWidth:180 }}>
                      <div style={{ fontSize:10, color:"#666" }}>
                        {p.providers.slice(0,2).join(", ")}{p.providers.length > 2 ? ` +${p.providers.length-2}` : ""}
                        {p.providers.length === 0 && <span style={{ color:"#2A2A40" }}>—</span>}
                      </div>
                    </td>
                    <td style={{ padding:"10px 14px" }}>
                      <Badge urgency={p.urgency} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ textAlign:"center", padding:32, color:"#333" }}>Nenhum projeto encontrado.</div>
          )}
        </div>
        <div style={{ marginTop:8, fontSize:10, color:"#2A2A40", textAlign:"right" }}>
          {filtered.length} de {enriched.length} projetos
        </div>
      </>)}

      {/* ── VIEW: PMs ── */}
      {view === "pms" && (
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12 }}>
          {pmStats.map(s => {
            const color = PM_COLORS[s.pm]||"#888";
            const myProjects = enriched.filter(p=>p.pm===s.pm);
            return (
              <div key={s.pm} className="card" style={{ padding:"18px 20px", borderTop:`2px solid ${color}` }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14 }}>
                  <div>
                    <div style={{ fontWeight:700, color:"#fff", fontSize:14 }}>{s.pm.split(" ")[0]}</div>
                    <div style={{ fontSize:10, color:"#444", marginTop:2 }}>{s.pm.split(" ").slice(1).join(" ")}</div>
                  </div>
                  <span className="mono" style={{ fontSize:28, color, fontWeight:500 }}>{s.total}</span>
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:6, marginBottom:14 }}>
                  {[
                    { l:"Atrasados", v:s.overdue, c:"#EF4444" },
                    { l:"Hoje",      v:s.today,   c:"#F97316" },
                    { l:"Em breve",  v:s.soon,    c:"#EAB308" },
                  ].map(m=>(
                    <div key={m.l} style={{ background:"#080812", borderRadius:8, padding:"8px 10px", textAlign:"center" }}>
                      <div style={{ fontSize:9, color:"#444", marginBottom:3, textTransform:"uppercase", letterSpacing:"0.06em" }}>{m.l}</div>
                      <div className="mono" style={{ fontSize:20, color:m.v>0?m.c:"#2A2A40", fontWeight:600 }}>{m.v}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                  {myProjects.slice(0,4).map(p=>(
                    <div key={p.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
                      padding:"5px 8px", background:"#080812", borderRadius:6,
                      borderLeft:`2px solid ${URGENCY[p.urgency].color}` }}>
                      <span style={{ fontSize:11, color:"#888" }}>{p.game.length > 22 ? p.game.slice(0,22)+"…" : p.game}</span>
                      <Badge urgency={p.urgency} />
                    </div>
                  ))}
                  {myProjects.length > 4 && (
                    <div style={{ fontSize:10, color:"#444", textAlign:"center", marginTop:2 }}>
                      +{myProjects.length-4} projetos
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── VIEW: CLIENTS ── */}
      {view === "clients" && (
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
          <div className="card" style={{ padding:"18px 20px" }}>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:14 }}>Volume por cliente</div>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {clientStats.map(([client, count]) => {
                const pct = (count / stats.total) * 100;
                const clientProjects = enriched.filter(p=>p.client===client);
                const hasOverdue = clientProjects.some(p=>p.urgency==="overdue");
                return (
                  <div key={client}>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
                      <span style={{ fontSize:12, color: hasOverdue ? "#EF4444" : "#aaa" }}>
                        {hasOverdue && "⚠ "}{client}
                      </span>
                      <span className="mono" style={{ fontSize:12, color:"#60A5FA", fontWeight:600 }}>{count}</span>
                    </div>
                    <div style={{ height:4, background:"#1A1A30", borderRadius:2, overflow:"hidden" }}>
                      <div style={{ height:"100%", width:`${pct}%`, background:"#60A5FA", borderRadius:2 }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="card" style={{ padding:"18px 20px" }}>
            <div style={{ fontSize:9, color:"#444", textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:14 }}>Projetos críticos por cliente</div>
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {clients.map(client => {
                const cp = enriched.filter(p=>p.client===client);
                const overdue = cp.filter(p=>p.urgency==="overdue").length;
                const today = cp.filter(p=>p.urgency==="today").length;
                const soon = cp.filter(p=>p.urgency==="soon").length;
                if (!overdue && !today && !soon) return null;
                return (
                  <div key={client} style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
                    padding:"8px 12px", background:"#080812", borderRadius:8,
                    borderLeft:`2px solid ${overdue?"#EF4444":today?"#F97316":"#EAB308"}` }}>
                    <span style={{ fontSize:12, color:"#aaa" }}>{client}</span>
                    <div style={{ display:"flex", gap:6 }}>
                      {overdue > 0 && <span style={{ fontSize:10, color:"#EF4444", fontWeight:700 }}>{overdue} atrasado</span>}
                      {today > 0 && <span style={{ fontSize:10, color:"#F97316", fontWeight:700 }}>{today} hoje</span>}
                      {soon > 0 && <span style={{ fontSize:10, color:"#EAB308", fontWeight:700 }}>{soon} breve</span>}
                    </div>
                  </div>
                );
              }).filter(Boolean)}
            </div>
          </div>
        </div>
      )}

      <div style={{ marginTop:14, textAlign:"center", fontSize:10, color:"#1A1A30", fontFamily:"'DM Mono',monospace" }}>
        Team Quoted · Dados exportados do Terrasoft · 04 Mar 2026
      </div>
    </div>
  );
}
